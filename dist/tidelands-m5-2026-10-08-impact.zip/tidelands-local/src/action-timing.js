// Gameplay impact and rendered swing use the same game-clock interval.
export const ATTACK_DURATION=.45;
export const ATTACK_IMPACT=ATTACK_DURATION/2;
