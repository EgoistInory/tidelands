import * as THREE from '../vendor/three.module.min.js';

// Keep the camera on the player's side of solid scenery, including its near plane.
export function unobstructedCamera(focus,desired,boxes,heightAt){
  const delta=desired.clone().sub(focus),length=delta.length();
  if(length<.001)return desired.clone();
  const ray=new THREE.Ray(focus,delta.divideScalar(length)),hit=new THREE.Vector3();
  let distance=length;
  for(const box of boxes){
    if(box.containsPoint(focus))continue;
    if(ray.intersectBox(box,hit))distance=Math.min(distance,Math.max(.25,focus.distanceTo(hit)-.5));
  }
  for(let d=.5;d<distance;d+=.5){ray.at(d,hit);if(hit.y<heightAt(hit.x,hit.z)+.4){distance=Math.max(.25,d-.5);break;}}
  return ray.at(distance,new THREE.Vector3());
}
