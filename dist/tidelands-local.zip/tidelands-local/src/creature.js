import * as THREE from '../vendor/three.module.min.js';
import {mergeStaticParts} from './merge-parts.js';

// Each creature owns its materials so hit feedback never changes its neighbours.
export function createCreature(type,geometryCache=null){
  const root=new THREE.Group(),body=new THREE.Group(),legs=[],claws=[];
  const hide=new THREE.MeshStandardMaterial({color:type==='crab'?0xa75738:0x675444,roughness:.92});
  const dark=new THREE.MeshStandardMaterial({color:0x302b27,roughness:.8});
  const ivory=new THREE.MeshStandardMaterial({color:0xe7d6ad,roughness:.7});
  const shape=(parent,scale,position,mat=hide)=>{
    const mesh=new THREE.Mesh(new THREE.SphereGeometry(1,12,8),mat);
    mesh.scale.set(...scale);mesh.position.set(...position);mesh.castShadow=mesh.receiveShadow=true;parent.add(mesh);return mesh;
  };
  root.add(body);
  if(type==='crab'){
    shape(body,[1.05,.38,.8],[0,.72,0]);
    for(const side of [-1,1]){
      for(let i=0;i<3;i++){
        const joint=new THREE.Group();joint.position.set(side*.65,.65,(i-1)*.52);body.add(joint);
        shape(joint,[.65,.09,.11],[side*.5,-.13,0]);
        shape(joint,[.12,.3,.09],[side*1,-.35,0]);legs.push(joint);
      }
      const claw=new THREE.Group();claw.position.set(side*.8,.75,.65);body.add(claw);
      shape(claw,[.18,.16,.5],[side*.25,0,.25]);
      for(const finger of [-1,1])shape(claw,[.12,.2,.35],[side*.35+finger*.15,0,.73]);claws.push(claw);
      shape(body,[.065,.22,.065],[side*.4,1.1,.5],dark);
      shape(body,[.13,.13,.13],[side*.4,1.3,.5],dark);
    }
  }else{
    shape(body,[.85,.85,1.35],[0,1.35,0]);
    shape(body,[.63,.61,.73],[0,1.18,1.15]);
    shape(body,[.38,.25,.3],[0,1.03,1.77],dark);
    for(const side of [-1,1]){
      shape(body,[.15,.36,.21],[side*.45,1.88,1.05]);
      shape(body,[.09,.09,.09],[side*.48,1.4,1.51],dark);
      const tusk=shape(body,[.1,.32,.1],[side*.38,.95,1.78],ivory);tusk.rotation.x=-.5;
      for(const z of [-.8,.8]){
        const joint=new THREE.Group();joint.position.set(side*.53,.95,z);body.add(joint);
        shape(joint,[.19,.39,.2],[0,-.31,0]);shape(joint,[.2,.16,.26],[0,-.76,.04],dark);legs.push(joint);
      }
    }
    for(let i=0;i<7;i++)shape(body,[.09,.22,.15],[0,2.09,-.9+i*.27],dark);
    const tail=shape(body,[.09,.09,.45],[0,1.37,-1.45]);tail.rotation.x=-.5;
  }
  mergeStaticParts(body);
  for(const joint of [...legs,...claws])mergeStaticParts(joint);
  // Distant creatures keep their full silhouette, baked into one mesh per material.
  const distant=new THREE.Group(),surfaces=[hide,dark,ivory];let cached=geometryCache?.get(type);
  if(cached){
    for(const {geometry,slot} of cached.parts){const mesh=new THREE.Mesh(geometry,surfaces[slot]);mesh.castShadow=mesh.receiveShadow=true;distant.add(mesh);}
  }else{
    body.updateMatrixWorld(true);
    body.traverse(part=>{if(part.isMesh){const mesh=new THREE.Mesh(part.geometry.clone().applyMatrix4(part.matrixWorld),part.material);mesh.castShadow=mesh.receiveShadow=true;distant.add(mesh);}});
    mergeStaticParts(distant);
    if(geometryCache){cached={references:0,parts:distant.children.map(mesh=>({geometry:mesh.geometry,slot:surfaces.indexOf(mesh.material)}))};geometryCache.set(type,cached);}
  }
  let releaseDistant;
  if(cached){
    cached.references++;let released=false;const geometries=new Set(cached.parts.map(p=>p.geometry));
    releaseDistant=()=>{if(!released){released=true;if(--cached.references===0){geometries.forEach(g=>g.dispose());geometryCache.delete(type);}}return geometries;};
  }
  distant.visible=false;root.add(distant);
  root.userData={type,body,distant,releaseDistant,far:false,legs,claws,hide,phase:0,last:null,hp:null,hitAt:-100,deadAt:null};
  return root;
}

export function animateCreature(root,enemy,time,dt,height,target){
  const u=root.userData,last=u.last;
  if(u.hp!==null&&enemy.hp<u.hp)u.hitAt=time;
  if(enemy.hp<=0&&u.deadAt===null)u.deadAt=u.hp===null?time-.5:time;
  if(enemy.hp>0)u.deadAt=null;
  const distance=last?Math.hypot(enemy.x-last.x,enemy.z-last.z):0;
  const moving=distance>.0001&&distance<4;
  if(moving)u.phase+=distance*(u.type==='crab'?5:3.2);
  if(moving||Math.hypot(target.x-enemy.x,target.z-enemy.z)<15){
    const angle=moving?Math.atan2(enemy.x-last.x,enemy.z-last.z):Math.atan2(target.x-enemy.x,target.z-enemy.z);
    const delta=Math.atan2(Math.sin(angle-root.rotation.y),Math.cos(angle-root.rotation.y));root.rotation.y+=delta*(1-Math.exp(-dt*10));
  }
  const attackAge=time-(enemy.attackAt??-100),attack=attackAge>=0&&attackAge<.35?Math.sin(attackAge/.35*Math.PI):0;
  const hurt=Math.max(0,1-(time-u.hitAt)/.24),death=u.deadAt===null?0:Math.min(1,Math.max(0,(time-u.deadAt)/.5));
  u.legs.forEach((leg,i)=>{const stride=moving?Math.sin(u.phase+(i%2)*Math.PI)*.55:0;leg.rotation.x=u.type==='boar'?stride:0;leg.rotation.z=u.type==='crab'?stride*.45:0;});
  u.claws.forEach((claw,i)=>{claw.rotation.x=-attack*.9;claw.rotation.y=(i?1:-1)*attack*.35;});
  u.body.position.y=(moving?Math.abs(Math.sin(u.phase))*.07:Math.sin(time*2)*.015)-death*.45;
  u.body.position.z=attack*.22-hurt*.18;u.body.rotation.x=u.type==='boar'?-attack*.18:0;u.body.rotation.z=death*1.3+hurt*.1;
  const range=Math.hypot(target.x-enemy.x,target.z-enemy.z);
  if(range>120)u.far=true;else if(range<100)u.far=false;
  // Combat and any actual travel always use animated limbs, even at a distance.
  const distant=u.far&&!moving&&attack===0&&hurt===0&&death===0;
  u.body.visible=!distant;u.distant.visible=distant;
  u.distant.position.copy(u.body.position);u.distant.rotation.copy(u.body.rotation);
  u.hide.emissive.setRGB(hurt*.28,hurt*.045,hurt*.015);
  root.position.set(enemy.x,height,enemy.z);root.visible=death<1;
  u.last={x:enemy.x,z:enemy.z};u.hp=enemy.hp;
}
